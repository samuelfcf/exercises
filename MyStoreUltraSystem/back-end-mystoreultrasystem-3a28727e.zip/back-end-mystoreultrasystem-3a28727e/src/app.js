import express from 'express';
import pg from 'pg';

const { Pool } = pg;

const connection = new Pool({
  user: 'bootcamp_role',
  host: 'localhost',
  port: 5432,
  database: 'exercicio_mystoreultrasystem_3a28727e',
  password: 'senha_super_hiper_ultra_secreta_do_role_do_bootcamp'
});

const app = express();
app.use(express.json());

app.get('/api/products', (req, res) => {
  connection.query('SELECT * FROM produtos').then(produtos => {
    res.send(produtos.rows);
  });
});

app.get('/api/products/:id', (req, res) => {
  const id = parseInt(req.params.id);

  if (isNaN(id)) {
    return res.sendStatus(400);
  }

  // busque pelo produto com o id especificado e envie o objeto de volta com status 200

  // remova esta linha depois de implementar
  // 501 siginifica "não implementado"
  res.sendStatus(501);
});

app.post('/api/products', (req, res) => {
  const { nome, preco, condicao } = req.body;
  
  // insira o produto no banco de dados e retorne com status 201

  // remova esta linha depois de implementar
  // 501 significa "não implementado"
  res.sendStatus(501);
});

app.listen(4000, () => {
  console.log('Server listening on port 4000.');
});
